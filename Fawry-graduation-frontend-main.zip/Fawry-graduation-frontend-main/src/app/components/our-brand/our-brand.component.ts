import { Component } from '@angular/core';

@Component({
  selector: 'app-our-brand',
  standalone: true,
  imports: [],
  templateUrl: './our-brand.component.html',
  styleUrl: './our-brand.component.css'
})
export class OurBrandComponent {

}
