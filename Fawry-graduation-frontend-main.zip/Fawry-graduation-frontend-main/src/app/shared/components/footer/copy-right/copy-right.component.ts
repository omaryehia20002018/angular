import { Component } from '@angular/core';

@Component({
  selector: 'app-copy-right',
  standalone: true,
  imports: [],
  templateUrl: './copy-right.component.html',
  styleUrl: './copy-right.component.css'
})
export class CopyRightComponent {

}
