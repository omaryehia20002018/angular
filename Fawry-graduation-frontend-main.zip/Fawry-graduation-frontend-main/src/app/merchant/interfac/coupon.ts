export interface Coupon {
  code: string;
  usageCount: number;
  expireDate: string;
  fxidValue: number;
  percentageValue: number;
}
