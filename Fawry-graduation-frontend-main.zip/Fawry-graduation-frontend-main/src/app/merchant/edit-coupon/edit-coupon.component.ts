import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-coupon',
  standalone: true,
  imports: [],
  templateUrl: './edit-coupon.component.html',
  styleUrl: './edit-coupon.component.css'
})
export class EditCouponComponent {

}
