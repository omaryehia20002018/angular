export interface Merchant {

    fname: string;
    lname: string;
    business_name: string;
    email: string;
    phone_number: string;
  


}
